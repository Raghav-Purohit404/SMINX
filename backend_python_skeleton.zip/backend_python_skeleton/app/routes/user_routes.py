from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List
from app.controllers.users import create_user, get_user, get_all_users, update_user, delete_user
from app.models.user import UserCreate, UserUpdate, UserOut
from app.database import get_db

router = APIRouter(prefix="/users", tags=["Users"])

# ---------- Create User ----------
@router.post("/", response_model=UserOut, status_code=status.HTTP_201_CREATED, summary="Create user")
async def create(user: UserCreate, db: AsyncSession = Depends(get_db)):
    try:
        new_user = await create_user(db, user)
        return new_user
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

# ---------- Get Single User ----------
@router.get("/{user_id}", response_model=UserOut, summary="Get user by ID")
async def read_user(user_id: int, db: AsyncSession = Depends(get_db)):
    user = await get_user(db, user_id)
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    return user

# ---------- Get All Users ----------
@router.get("/", response_model=List[UserOut], summary="Get all users")
async def read_all_users(db: AsyncSession = Depends(get_db)):
    return await get_all_users(db)

# ---------- Update User ----------
@router.put("/{user_id}", response_model=UserOut, summary="Update user by ID")
async def update(user_id: int, user_in: UserUpdate, db: AsyncSession = Depends(get_db)):
    user = await update_user(db, user_id, user_in)
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    return user

# ---------- Delete User ----------
@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Delete user by ID")
async def delete(user_id: int, db: AsyncSession = Depends(get_db)):
    success = await delete_user(db, user_id)
    if not success:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

