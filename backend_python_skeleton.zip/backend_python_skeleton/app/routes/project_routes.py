from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List
from app.services.project_service import (
    create_project, get_project, get_all_projects,
    update_project, delete_project
)
from app.schemas.project import ProjectCreate, ProjectUpdate, ProjectOut
from app.database import get_db

router = APIRouter(prefix="/projects", tags=["Projects"])

# ---------- CREATE ----------
@router.post("/", response_model=ProjectOut)
async def create_new_project(data: ProjectCreate, db: AsyncSession = Depends(get_db)):
    project = await create_project(db, data)
    return project

# ---------- READ ALL ----------
@router.get("/", response_model=List[ProjectOut])
async def list_projects(db: AsyncSession = Depends(get_db)):
    return await get_all_projects(db)

# ---------- READ ONE ----------
@router.get("/{project_id}", response_model=ProjectOut)
async def read_project(project_id: str, db: AsyncSession = Depends(get_db)):
    project = await get_project(db, project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project

# ---------- UPDATE ----------
@router.put("/{project_id}", response_model=ProjectOut)
async def modify_project(project_id: str, data: ProjectUpdate, db: AsyncSession = Depends(get_db)):
    updated = await update_project(db, project_id, data)
    if not updated:
        raise HTTPException(status_code=404, detail="Project not found")
    return updated

# ---------- DELETE ----------
@router.delete("/{project_id}")
async def remove_project(project_id: str, db: AsyncSession = Depends(get_db)):
    deleted = await delete_project(db, project_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Project not found")
    return {"message": "Project deleted successfully"}
