import uuid
from sqlalchemy import Column, String, Text, JSON, ForeignKey, DateTime
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.database import Base  # updated to match async database structure

class Project(Base):
    __tablename__ = "projects"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    title = Column(String(100), nullable=False, unique=True, index=True)
    description = Column(Text, nullable=True)
    skills_required = Column(JSON, default=list)
    owner_id = Column(String, ForeignKey("users.id"), nullable=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Optional: relationship to User model
    # owner = relationship("User", back_populates="projects")

    def __repr__(self):
        return f"<Project {self.title}>"

