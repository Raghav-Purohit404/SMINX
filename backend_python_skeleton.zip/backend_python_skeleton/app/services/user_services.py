import uuid
from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.exc import IntegrityError
from app.models.user_model import User  # updated import to match project structure
from app.schemas.user import UserCreate, UserUpdate
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# ---------- Password Helpers ----------
def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


# ------------------- Create User -------------------
async def create_user(db: AsyncSession, user_in: UserCreate) -> User:
    hashed_pw = hash_password(user_in.password)
    new_user = User(
        id=str(uuid.uuid4()),
        name=user_in.name,
        email=user_in.email,
        hashed_password=hashed_pw,
        skills=user_in.skills,
    )
    db.add(new_user)
    try:
        await db.commit()
        await db.refresh(new_user)
        return new_user
    except IntegrityError:
        await db.rollback()
        raise ValueError("User with this email already exists")


# ------------------- Get User By ID -------------------
async def get_user(db: AsyncSession, user_id: str) -> Optional[User]:
    result = await db.execute(select(User).where(User.id == user_id))
    return result.scalar_one_or_none()


# ------------------- Get All Users -------------------
async def get_all_users(db: AsyncSession) -> List[User]:
    result = await db.execute(select(User))
    return result.scalars().all()


# ------------------- Update User -------------------
async def update_user(db: AsyncSession, user_id: str, user_in: UserUpdate) -> Optional[User]:
    user = await get_user(db, user_id)
    if not user:
        return None

    for field, value in user_in.dict(exclude_unset=True).items():
        if field == "password" and value:
            setattr(user, "hashed_password", hash_password(value))
        elif field == "skills" and value is not None:
            setattr(user, field, value)
        elif value is not None:
            setattr(user, field, value)

    db.add(user)
    await db.commit()
    await db.refresh(user)
    return user


# ------------------- Delete User -------------------
async def delete_user(db: AsyncSession, user_id: str) -> bool:
    user = await get_user(db, user_id)
    if not user:
        return False

    await db.delete(user)
    await db.commit()
    return True
