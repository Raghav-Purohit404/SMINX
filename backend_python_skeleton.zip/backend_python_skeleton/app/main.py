# app/main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import user_routes, project_routes, auth_routes
from app.database import init_db  # async DB initializer

app = FastAPI(title="SMINX")

# ---------- CORS Middleware ----------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Update with specific origins in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------- Include Routers ----------
app.include_router(user_routes.router, prefix="/api/users", tags=["Users"])
app.include_router(project_routes.router, prefix="/api/projects", tags=["Projects"])
app.include_router(auth_routes.router, prefix="/api/auth", tags=["Auth"])

# ---------- Startup Event ----------
@app.on_event("startup")
async def on_startup():
    """
    Initialize database tables asynchronously at app startup.
    """
    await init_db()
    print("Database initialized successfully!")

# ---------- Root / Health Check ----------
@app.get("/", summary="Health Check")
async def root():
    return {"message": "API is running!"}

# ---------- Run Instructions ----------
# To run locally: uvicorn main:app --reload
