from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime


# ---------- Base Schema ----------
class ProjectBase(BaseModel):
    title: str = Field(..., min_length=3, max_length=100, description="Project title")
    description: Optional[str] = Field(None, description="Detailed description of the project")
    skills_required: List[str] = Field(default_factory=list, description="Skills needed for the project")


# ---------- Create Schema ----------
class ProjectCreate(ProjectBase):
    owner_id: str = Field(..., description="User ID of the project owner")  # string to match UUID style


# ---------- Update Schema ----------
class ProjectUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=3, max_length=100)
    description: Optional[str] = None
    skills_required: Optional[List[str]] = None  # None allows partial updates


# ---------- Response Schema ----------
class ProjectOut(ProjectBase):
    id: str
    owner_id: str
    created_at: datetime
    updated_at: Optional[datetime]  # optional in case not yet updated

    class Config:
        orm_mode = True
