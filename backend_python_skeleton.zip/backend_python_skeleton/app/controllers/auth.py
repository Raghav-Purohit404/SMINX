#from fastapi import HTTPException
from pydantic import BaseModel, EmailStr
from datetime import datetime, timedelta
from jose import jwt
import os

# ---------- Login Schema ----------
class LoginSchema(BaseModel):
    email: EmailStr

# ---------- JWT Config ----------
JWT_SECRET = os.getenv("JWT_SECRET", "dev-secret-change-me")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
JWT_EXP_HOURS = int(os.getenv("JWT_EXP_HOURS", "24"))

# ---------- Login Function ----------
async def login(payload: LoginSchema):
    """
    Minimal login that:
      - enforces college email domain
      - issues a signed JWT (HS256) with basic claims: sub, iat, exp
    """
    email = payload.email.strip().lower()
    if not email.endswith("@college.edu"):
        raise HTTPException(status_code=400, detail="Use college email")

    now = datetime.utcnow()
    expiry = now + timedelta(hours=JWT_EXP_HOURS)
    claims = {
        "sub": email,
        "iat": int(now.timestamp()),
        "exp": int(expiry.timestamp()),
        "user_id": f"user:{email}",
        "email": email,
    }

    token = jwt.encode(claims, JWT_SECRET, algorithm=JWT_ALGORITHM)
    return {
        "token": token,
        "token_type": "bearer",
        "expires_at": expiry.isoformat(),
        "email": email
    }
